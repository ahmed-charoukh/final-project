<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Product;
use App\Models\Setting;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $admin = User::create([
            'name' => 'Admin',
            'email' => 'admin@meatshop.test',
            'password' => Hash::make('12345678'),
            'role' => 'admin',
            'status' => true,
        ]);

        $meat = Category::create([
            'title' => 'Meat',
            'keywords' => 'meat, fresh, beef, lamb',
            'description' => 'Fresh meat category',
            'status' => true,
        ]);

        $livestock = Category::create([
            'title' => 'Livestock',
            'keywords' => 'cow, sheep, livestock',
            'description' => 'Livestock category',
            'status' => true,
        ]);

        Product::create([
            'category_id' => $meat->id,
            'user_id' => $admin->id,
            'title' => 'Fresh Beef',
            'keywords' => 'beef, meat',
            'description' => 'Fresh beef meat',
            'detail' => 'High quality beef product for daily use.',
            'image' => null,
            'price' => 250,
            'stock' => 20,
            'minstock' => 3,
            'discount' => 0,
            'status' => true,
        ]);

        Product::create([
            'category_id' => $meat->id,
            'user_id' => $admin->id,
            'title' => 'Lamb Meat',
            'keywords' => 'lamb, meat',
            'description' => 'Fresh lamb meat',
            'detail' => 'Good quality lamb meat with fair price.',
            'image' => null,
            'price' => 300,
            'stock' => 15,
            'minstock' => 3,
            'discount' => 5,
            'status' => true,
        ]);

        Product::create([
            'category_id' => $livestock->id,
            'user_id' => $admin->id,
            'title' => 'Sheep',
            'keywords' => 'sheep, livestock',
            'description' => 'Healthy sheep',
            'detail' => 'Selected sheep from trusted farm.',
            'image' => null,
            'price' => 8500,
            'stock' => 5,
            'minstock' => 1,
            'discount' => 0,
            'status' => true,
        ]);

        Setting::create([
            'title' => 'Meat Shop',
            'phone' => '+90 555 000 0000',
            'email' => 'info@meatshop.test',
            'address' => 'Istanbul, Türkiye',
            'description' => 'Fresh meat and livestock Laravel MVC project.',
        ]);
    }
}
