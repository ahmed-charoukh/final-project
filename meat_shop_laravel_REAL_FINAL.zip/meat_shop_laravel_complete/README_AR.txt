مشروع Meat Shop Laravel كامل — Advanced Web
==========================================

هذا الإصدار تم تصليحه ليكون مشروع Laravel كامل قابل للتشغيل بعد تثبيت مكتبات Composer.
المشروع يطابق فكرة ملف الدكتور: Front + Admin + Layouts + MVC + Routes + Controllers + Models + Migrations + Relations + Fillable.

مهم جداً:
- مجلد vendor غير موجود لأن حجمه كبير ولا يُسلّم عادةً.
- لتشغيل أي مشروع Laravel يجب تنفيذ composer install مرة واحدة.

طريقة التشغيل السريعة SQLite — الأسهل:
1) فك الضغط عن الملف.
2) افتح CMD داخل مجلد المشروع.
3) شغّل:
   composer install
   php artisan migrate:fresh --seed
   php artisan serve

4) افتح:
   http://127.0.0.1:8000
   http://127.0.0.1:8000/admin

طريقة MySQL / phpMyAdmin:
1) أنشئ قاعدة بيانات باسم meat_shop.
2) افتح ملف .env وعدل:
   DB_CONNECTION=mysql
   DB_HOST=127.0.0.1
   DB_PORT=3306
   DB_DATABASE=meat_shop
   DB_USERNAME=root
   DB_PASSWORD=
3) شغّل:
   php artisan migrate:fresh --seed
   php artisan serve

ماذا تم تصليحه وتحسينه؟
- أضفت Laravel skeleton كامل: artisan, composer.json, bootstrap, config, public/index.php, .env, storage.
- أضفت users migration حتى علاقات user_id تعمل بدون خطأ.
- أضفت User model وفيه relations: products() و orders().
- أضفت user() relation داخل Product model.
- أضفت admin/footer.blade.php وربطته داخل admin layout.
- أضفت حقل Image URL داخل Product form وربطته بالـ validation.
- عدلت DatabaseSeeder ليضيف Admin user + Categories + Products + Settings.
- أضفت route باسم admin مطابق لفكرة الدكتور، مع بقاء admin.dashboard.

محتوى المشروع:
- Front master layout: resources/views/layouts/home.blade.php
- Admin master layout: resources/views/layouts/admin.blade.php
- Front pages: home, products, product detail, cart, checkout, contact, order success
- Admin CRUD: categories, products, orders
- Models: User, Category, Product, Order, OrderItem, Review, Setting
- Migrations: users, categories, products, orders, order_items, reviews, settings
- Relations:
  Category hasMany Product
  Product belongsTo Category
  Product belongsTo User
  User hasMany Product
  User hasMany Order
  Order hasMany OrderItem
  OrderItem belongsTo Product
  Review belongsTo Product

Admin sample account in database:
Email: admin@meatshop.test
Password: 12345678
ملاحظة: لا يوجد login system، الحساب فقط لإثبات وجود users/user_id/relations بالقاعدة.
