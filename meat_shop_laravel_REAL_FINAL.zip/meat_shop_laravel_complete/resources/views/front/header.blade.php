<header class="bg-danger text-white py-3"><div class="container d-flex flex-wrap justify-content-between align-items-center gap-3">
<a href="{{ route('home') }}" class="text-white text-decoration-none h3 mb-0"><i class="fa-solid fa-drumstick-bite"></i> Meat Shop</a>
<form action="{{ route('products.index') }}" method="GET" class="d-flex" style="max-width:420px;width:100%;">
<input type="text" name="search" class="form-control" placeholder="Search products..." value="{{ request('search') }}"><button class="btn btn-warning ms-2" type="submit">Search</button></form>
<div class="d-flex gap-2 align-items-center">
<a href="{{ route('cart.show') }}" class="btn btn-light"><i class="fa-solid fa-cart-shopping"></i> Cart</a>
@auth
<span class="small">{{ auth()->user()->name }}</span>
<form method="POST" action="{{ route('logout') }}">@csrf<button class="btn btn-outline-light btn-sm">Logout</button></form>
@else
<a href="{{ route('login') }}" class="btn btn-outline-light btn-sm">Login</a><a href="{{ route('register') }}" class="btn btn-warning btn-sm">Register</a>
@endauth
</div>
</div></header>
