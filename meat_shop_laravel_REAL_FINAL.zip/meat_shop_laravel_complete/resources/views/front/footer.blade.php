<footer class="bg-dark text-white py-4 mt-5"><div class="container text-center"><p class="mb-1">Meat Shop Laravel Project</p><small>Advanced Web Project</small></div></footer>
