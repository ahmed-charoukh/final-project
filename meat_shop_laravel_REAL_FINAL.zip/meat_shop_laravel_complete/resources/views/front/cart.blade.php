@extends('layouts.home')
@section('title', 'Cart')
@section('content')
<h2>Shopping Cart</h2>
<div class="row"><div class="col-md-8"><div class="card"><div class="card-body">
@if($cartItems->isEmpty())
    <div class="alert alert-info">Cart is empty.</div>
@else
    <table class="table align-middle"><thead><tr><th>Product</th><th>Price</th><th>Qty</th><th>Total</th><th></th></tr></thead><tbody>
    @foreach($cartItems as $item)
        <tr><td>{{ $item->product->title ?? 'Deleted product' }}</td><td>{{ $item->product->price ?? 0 }} TL</td><td><form method="POST" action="{{ route('cart.update', $item) }}" class="d-flex gap-2">@csrf @method('PATCH')<input type="number" name="quantity" value="{{ $item->quantity }}" min="1" max="{{ $item->product->stock ?? 1 }}" class="form-control form-control-sm" style="width:80px"><button class="btn btn-sm btn-outline-primary">Update</button></form></td><td>{{ $item->product ? number_format($item->product->price * $item->quantity, 2) : '0.00' }} TL</td><td><form method="POST" action="{{ route('cart.remove', $item) }}">@csrf @method('DELETE')<button class="btn btn-sm btn-danger">Remove</button></form></td></tr>
    @endforeach
    </tbody></table>
@endif
</div></div></div><div class="col-md-4"><div class="card"><div class="card-body"><h5>Total: {{ number_format($subtotal, 2) }} TL</h5><a href="{{ route('checkout') }}" class="btn btn-success w-100 {{ $cartItems->isEmpty() ? 'disabled' : '' }}">Checkout</a></div></div></div></div>
@endsection
