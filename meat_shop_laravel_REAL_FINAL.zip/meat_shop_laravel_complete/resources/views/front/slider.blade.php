<section class="hero-section text-white text-center d-flex align-items-center"><div class="container">
<h1>Fresh Meat and Livestock Shop</h1><p class="lead">High quality products with Laravel MVC structure.</p>
<a href="{{ route('products.index') }}" class="btn btn-warning btn-lg">Shop Now</a>
</div></section>
