@extends('layouts.home')
@section('title', 'Home - Meat Shop')
@section('slider') @include('front.slider') @endsection
@section('content')
<h2 class="section-title mb-4">Featured Products</h2>
<div class="row g-4">
@forelse($featured_products as $product)
<div class="col-md-3"><div class="card product-card h-100">
@if($product->image)<img src="{{ asset('storage/'.$product->image) }}" class="card-img-top" style="height:160px;object-fit:cover" alt="{{ $product->title }}">@endif
<div class="card-body"><h5>{{ $product->title }}</h5><p class="text-muted">{{ $product->category->title ?? 'No Category' }}</p><p>{{ Str::limit($product->description, 70) }}</p><h4 class="text-danger">{{ $product->price }} TL</h4><form method="POST" action="{{ route('cart.add', $product) }}">@csrf<input type="hidden" name="quantity" value="1"><button class="btn btn-warning w-100" {{ $product->stock <= 0 ? 'disabled' : '' }}>Add to Cart</button></form><a href="{{ route('products.show', $product) }}" class="btn btn-outline-secondary w-100 mt-2">Details</a></div></div></div>
@empty
<div class="col-12"><div class="alert alert-info">No products yet. Go to Admin and add products.</div></div>
@endforelse
</div>
@endsection
