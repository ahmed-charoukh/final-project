@extends('layouts.home')
@section('title','Contact')
@section('content')
<h2>Contact Us</h2>
<div class="row"><div class="col-md-7"><div class="card"><div class="card-body">
@if($errors->any())<div class="alert alert-danger"><ul class="mb-0">@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>@endif
<form method="POST" action="{{ route('contact.store') }}">@csrf
<div class="mb-3"><label>Name</label><input name="name" class="form-control" value="{{ old('name', auth()->user()->name ?? '') }}" required></div>
<div class="mb-3"><label>Email</label><input type="email" name="email" class="form-control" value="{{ old('email', auth()->user()->email ?? '') }}"></div>
<div class="mb-3"><label>Phone</label><input name="phone" class="form-control" value="{{ old('phone') }}"></div>
<div class="mb-3"><label>Subject</label><input name="subject" class="form-control" value="{{ old('subject') }}"></div>
<div class="mb-3"><label>Message</label><textarea name="message" class="form-control" rows="5" required>{{ old('message') }}</textarea></div>
<button class="btn btn-danger">Send Message</button>
</form>
</div></div></div><div class="col-md-5"><div class="card"><div class="card-body"><h5>Meat Shop</h5><p>Fresh meat products with a Laravel Advanced Web project structure.</p><p>Email: info@meatshop.test</p><p>Phone: +90 555 000 0000</p></div></div></div></div>
@endsection
