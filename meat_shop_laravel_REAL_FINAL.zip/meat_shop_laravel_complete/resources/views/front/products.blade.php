@extends('layouts.home')
@section('title', 'Products')
@section('content')
<h2 class="section-title mb-4">Products</h2>
<div class="row">
    <div class="col-md-3">
        <div class="card mb-4"><div class="card-body"><h5>Categories</h5><a href="{{ route('products.index') }}" class="d-block mb-2">All Products</a>@foreach($categories as $cat)<a href="{{ route('products.byCategory', $cat) }}" class="d-block mb-2">{{ $cat->title }}</a>@endforeach</div></div>
    </div>
    <div class="col-md-9"><div class="row g-4">
    @forelse($products as $product)
        <div class="col-md-4"><div class="card product-card h-100">
            @if($product->image)<img src="{{ asset('storage/'.$product->image) }}" class="card-img-top" style="height:170px;object-fit:cover" alt="{{ $product->title }}">@endif
            <div class="card-body"><h5>{{ $product->title }}</h5><p class="text-muted">{{ $product->category->title ?? 'No Category' }}</p><p>{{ Str::limit($product->description, 80) }}</p><h4 class="text-danger">{{ $product->price }} TL</h4><p>Stock: {{ $product->stock }}</p>
            <form method="POST" action="{{ route('cart.add', $product) }}">@csrf<input type="hidden" name="quantity" value="1"><button class="btn btn-warning w-100" {{ $product->stock <= 0 ? 'disabled' : '' }}>Add to Cart</button></form>
            <a href="{{ route('products.show', $product) }}" class="btn btn-outline-secondary w-100 mt-2">Details</a></div></div></div>
    @empty <div class="col-12"><div class="alert alert-info">No products found.</div></div> @endforelse
    </div><div class="mt-4">{{ $products->links() }}</div></div>
</div>
@endsection
