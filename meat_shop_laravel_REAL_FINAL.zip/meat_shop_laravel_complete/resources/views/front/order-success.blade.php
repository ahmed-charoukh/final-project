@extends('layouts.home')
@section('title', 'Order Success')
@section('content')
<div class="alert alert-success"><h3>Order Created Successfully!</h3><p>Order Number: #{{ $order->id }}</p><p>Total: {{ $order->total }} TL</p></div><h4>Items</h4><table class="table table-bordered"><thead><tr><th>Product</th><th>Qty</th><th>Total</th></tr></thead><tbody>@foreach($order->items as $item)<tr><td>{{ $item->product_name }}</td><td>{{ $item->quantity }}</td><td>{{ $item->total }}</td></tr>@endforeach</tbody></table><a href="{{ route('home') }}" class="btn btn-primary" onclick="localStorage.removeItem('cart')">Back Home</a>
@endsection
