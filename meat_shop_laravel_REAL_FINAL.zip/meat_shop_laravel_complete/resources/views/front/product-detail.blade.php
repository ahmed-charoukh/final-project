@extends('layouts.home')
@section('title', $product->title)
@section('content')
<div class="row g-4">
    <div class="col-md-6"><div class="card"><div class="card-body text-center">@if($product->image)<img src="{{ asset('storage/'.$product->image) }}" class="img-fluid rounded" alt="{{ $product->title }}">@else<div class="display-1">🥩</div>@endif</div></div></div>
    <div class="col-md-6"><h1>{{ $product->title }}</h1><p class="text-muted">Category: {{ $product->category->title ?? 'No Category' }}</p><h3 class="text-danger">{{ $product->price }} TL</h3><p>{{ $product->description }}</p><p>{{ $product->detail }}</p><p>Stock: {{ $product->stock }}</p><p>Average Review: {{ $reviews_avg ?? 0 }} / 5</p>
        <form method="POST" action="{{ route('cart.add', $product) }}" class="d-flex gap-2">@csrf<input type="number" name="quantity" value="1" min="1" max="{{ $product->stock }}" class="form-control" style="max-width:120px"><button class="btn btn-warning" {{ $product->stock <= 0 ? 'disabled' : '' }}>Add to Cart</button></form>
    </div>
</div>
<hr class="my-5"><h3>Reviews</h3>
<form method="POST" action="{{ route('reviews.store') }}" class="card card-body mb-4">@csrf<input type="hidden" name="product_id" value="{{ $product->id }}"><div class="mb-3"><label>Name</label><input type="text" name="name" class="form-control" value="{{ auth()->user()->name ?? '' }}" required></div><div class="mb-3"><label>Rating</label><select name="rating" class="form-select" required><option value="5">5</option><option value="4">4</option><option value="3">3</option><option value="2">2</option><option value="1">1</option></select></div><div class="mb-3"><label>Comment</label><textarea name="comment" class="form-control"></textarea></div><button class="btn btn-primary">Submit Review</button></form>
@foreach($product->reviews as $review)<div class="card mb-2"><div class="card-body"><strong>{{ $review->name }}</strong> — {{ $review->rating }}/5<p>{{ $review->comment }}</p></div></div>@endforeach
@endsection
