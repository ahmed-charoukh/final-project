<nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom sticky-top"><div class="container">
<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"><span class="navbar-toggler-icon"></span></button>
<div class="collapse navbar-collapse" id="navbarNav"><ul class="navbar-nav ms-auto">
<li class="nav-item"><a class="nav-link" href="{{ route('home') }}">Home</a></li>
<li class="nav-item"><a class="nav-link" href="{{ route('products.index') }}">Products</a></li>
<li class="nav-item"><a class="nav-link" href="{{ route('cart.show') }}">Cart</a></li>
<li class="nav-item"><a class="nav-link" href="{{ route('contact') }}">Contact</a></li>
@auth @if(auth()->user()->role === 'admin')<li class="nav-item"><a class="nav-link text-danger fw-bold" href="{{ route('admin.dashboard') }}">Admin</a></li>@endif @endauth
</ul></div></div></nav>
