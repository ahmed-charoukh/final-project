@extends('layouts.admin')
@section('title','Edit Category') @section('page_title','Edit Category')
@section('content')
<form method="POST" action="{{ route('admin.categories.update', $category) }}" class="card card-body">@csrf @method('PUT')<div class="mb-3"><label>Title</label><input name="title" class="form-control" value="{{ $category->title }}" required></div><div class="mb-3"><label>Keywords</label><input name="keywords" class="form-control" value="{{ $category->keywords }}"></div><div class="mb-3"><label>Description</label><textarea name="description" class="form-control">{{ $category->description }}</textarea></div><div class="form-check mb-3"><input type="checkbox" name="status" value="1" class="form-check-input" {{ $category->status ? 'checked' : '' }}><label class="form-check-label">Active</label></div><button class="btn btn-primary">Update</button></form>
@endsection
