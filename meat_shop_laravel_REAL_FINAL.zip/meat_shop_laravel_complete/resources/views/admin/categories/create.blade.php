@extends('layouts.admin')
@section('title','Add Category') @section('page_title','Add Category')
@section('content')
<form method="POST" action="{{ route('admin.categories.store') }}" class="card card-body">@csrf<div class="mb-3"><label>Title</label><input name="title" class="form-control" required></div><div class="mb-3"><label>Keywords</label><input name="keywords" class="form-control"></div><div class="mb-3"><label>Description</label><textarea name="description" class="form-control"></textarea></div><div class="form-check mb-3"><input type="checkbox" name="status" value="1" class="form-check-input" checked><label class="form-check-label">Active</label></div><button class="btn btn-primary">Save</button></form>
@endsection
