@extends('layouts.admin')
@section('title','Categories') @section('page_title','Categories')
@section('content')
<a href="{{ route('admin.categories.create') }}" class="btn btn-primary mb-3">Add Category</a><table class="table table-bordered bg-white"><thead><tr><th>ID</th><th>Title</th><th>Status</th><th>Actions</th></tr></thead><tbody>@foreach($categories as $category)<tr><td>{{ $category->id }}</td><td>{{ $category->title }}</td><td>{{ $category->status ? 'Active' : 'Passive' }}</td><td><a href="{{ route('admin.categories.edit', $category) }}" class="btn btn-sm btn-warning">Edit</a><form action="{{ route('admin.categories.destroy', $category) }}" method="POST" class="d-inline">@csrf @method('DELETE')<button class="btn btn-sm btn-danger" onclick="return confirm('Delete?')">Delete</button></form></td></tr>@endforeach</tbody></table>{{ $categories->links() }}
@endsection
