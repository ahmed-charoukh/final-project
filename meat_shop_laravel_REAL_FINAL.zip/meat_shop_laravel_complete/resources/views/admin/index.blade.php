@extends('layouts.admin')
@section('title','Dashboard') @section('page_title','Dashboard')
@section('content')
<div class="row g-4"><div class="col-md-3"><div class="card bg-primary text-white"><div class="card-body"><h5>Categories</h5><h2>{{ $total_categories }}</h2></div></div></div><div class="col-md-3"><div class="card bg-success text-white"><div class="card-body"><h5>Products</h5><h2>{{ $total_products }}</h2></div></div></div><div class="col-md-3"><div class="card bg-warning text-dark"><div class="card-body"><h5>Orders</h5><h2>{{ $total_orders }}</h2></div></div></div><div class="col-md-3"><div class="card bg-danger text-white"><div class="card-body"><h5>Revenue</h5><h2>{{ $total_revenue }}</h2></div></div></div></div>
<div class="card mt-4"><div class="card-header">Recent Orders</div><div class="card-body"><table class="table"><thead><tr><th>ID</th><th>Name</th><th>Total</th><th>Status</th></tr></thead><tbody>@forelse($recent_orders as $order)<tr><td>#{{ $order->id }}</td><td>{{ $order->customer_name }}</td><td>{{ $order->total }}</td><td>{{ $order->status }}</td></tr>@empty<tr><td colspan="4">No orders yet.</td></tr>@endforelse</tbody></table></div></div>
@endsection
