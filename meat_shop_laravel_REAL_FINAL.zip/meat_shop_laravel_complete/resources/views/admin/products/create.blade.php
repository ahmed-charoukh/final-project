@extends('layouts.admin')
@section('title','Add Product') @section('page_title','Add Product')
@section('content')
@if($errors->any())<div class="alert alert-danger"><ul class="mb-0">@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>@endif
<form method="POST" action="{{ route('admin.products.store') }}" enctype="multipart/form-data" class="card card-body">@csrf @include('admin.products.form', ['product' => null])<button class="btn btn-primary">Save</button></form>
@endsection
