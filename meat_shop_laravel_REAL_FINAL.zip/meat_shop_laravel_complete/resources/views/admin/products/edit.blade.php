@extends('layouts.admin')
@section('title','Edit Product') @section('page_title','Edit Product')
@section('content')
@if($errors->any())<div class="alert alert-danger"><ul class="mb-0">@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>@endif
<form method="POST" action="{{ route('admin.products.update', $product) }}" enctype="multipart/form-data" class="card card-body">@csrf @method('PUT') @include('admin.products.form')<button class="btn btn-primary">Update</button></form>
@endsection
