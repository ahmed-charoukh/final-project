@extends('layouts.admin')
@section('title','Products') @section('page_title','Products')
@section('content')
<a href="{{ route('admin.products.create') }}" class="btn btn-primary mb-3">Add Product</a><table class="table table-bordered bg-white"><thead><tr><th>ID</th><th>Title</th><th>Category</th><th>Price</th><th>Stock</th><th>Actions</th></tr></thead><tbody>@foreach($products as $product)<tr><td>{{ $product->id }}</td><td>{{ $product->title }}</td><td>{{ $product->category->title ?? '-' }}</td><td>{{ $product->price }}</td><td>{{ $product->stock }}</td><td><a href="{{ route('admin.products.edit', $product) }}" class="btn btn-sm btn-warning">Edit</a><form action="{{ route('admin.products.destroy', $product) }}" method="POST" class="d-inline">@csrf @method('DELETE')<button class="btn btn-sm btn-danger" onclick="return confirm('Delete?')">Delete</button></form></td></tr>@endforeach</tbody></table>{{ $products->links() }}
@endsection
