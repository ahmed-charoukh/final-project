@extends('layouts.admin')
@section('title','Orders') @section('page_title','Orders')
@section('content')
<table class="table table-bordered bg-white"><thead><tr><th>ID</th><th>Name</th><th>Phone</th><th>Total</th><th>Status</th><th>Action</th></tr></thead><tbody>@foreach($orders as $order)<tr><td>#{{ $order->id }}</td><td>{{ $order->customer_name }}</td><td>{{ $order->phone }}</td><td>{{ $order->total }}</td><td>{{ $order->status }}</td><td><a href="{{ route('admin.orders.show', $order) }}" class="btn btn-sm btn-info">Show</a></td></tr>@endforeach</tbody></table>{{ $orders->links() }}
@endsection
