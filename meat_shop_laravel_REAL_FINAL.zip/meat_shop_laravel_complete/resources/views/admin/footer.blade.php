<footer class="bg-white border-top p-3 text-center text-muted small">
    Meat Shop Admin Panel © {{ date('Y') }} — Advanced Web Laravel Project
</footer>
