@extends('layouts.home')
@section('title','Login')
@section('content')
<div class="row justify-content-center">
    <div class="col-md-5">
        <div class="card shadow-sm">
            <div class="card-body">
                <h2 class="mb-4">Login</h2>
                @if($errors->any())
                    <div class="alert alert-danger">{{ $errors->first() }}</div>
                @endif
                <form method="POST" action="{{ route('login.post') }}">
                    @csrf
                    <div class="mb-3"><label>Email</label><input type="email" name="email" class="form-control" value="{{ old('email') }}" required></div>
                    <div class="mb-3"><label>Password</label><input type="password" name="password" class="form-control" required></div>
                    <div class="form-check mb-3"><input type="checkbox" name="remember" value="1" class="form-check-input" id="remember"><label for="remember" class="form-check-label">Remember me</label></div>
                    <button class="btn btn-danger w-100">Login</button>
                </form>
                <p class="mt-3 mb-0">No account? <a href="{{ route('register') }}">Create one</a></p>
                <hr>
                <small class="text-muted">Admin test: admin@meatshop.test / 12345678</small>
            </div>
        </div>
    </div>
</div>
@endsection
