<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class IsAdmin
{
    public function handle(Request $request, Closure $next): Response
    {
        if (!auth()->check()) {
            return redirect()->route('login')->with('error', 'Please login first.');
        }

        if (auth()->user()->role !== 'admin' || !auth()->user()->status) {
            abort(403, 'You are not allowed to access the admin panel.');
        }

        return $next($request);
    }
}
