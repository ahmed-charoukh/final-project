<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Order;
use App\Models\Product;
class AdminHomeController extends Controller {
    public function index() {
        $total_categories = Category::count(); $total_products = Product::count(); $total_orders = Order::count();
        $total_revenue = Order::sum('total'); $recent_orders = Order::latest()->limit(5)->get();
        return view('admin.index', compact('total_categories','total_products','total_orders','total_revenue','recent_orders'));
    }
}
