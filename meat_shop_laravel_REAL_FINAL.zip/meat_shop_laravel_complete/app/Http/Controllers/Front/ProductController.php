<?php
namespace App\Http\Controllers\Front;
use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Product;
use Illuminate\Http\Request;
class ProductController extends Controller {
    public function index(Request $request) {
        $categories = Category::where('status', true)->get();
        $query = Product::with('category')->where('status', true);
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('title', 'like', "%{$search}%")
                  ->orWhere('description', 'like', "%{$search}%")
                  ->orWhere('keywords', 'like', "%{$search}%");
            });
        }
        $products = $query->latest()->paginate(12);
        return view('front.products', compact('products', 'categories'));
    }
    public function show(Product $product) {
        $product->load(['category', 'reviews']);
        $reviews_avg = round($product->reviews()->avg('rating'), 1);
        $categories = Category::where('status', true)->get();
        return view('front.product-detail', compact('product', 'reviews_avg', 'categories'));
    }
    public function byCategory(Category $category) {
        $categories = Category::where('status', true)->get();
        $products = Product::with('category')->where('status', true)->where('category_id', $category->id)->latest()->paginate(12);
        return view('front.products', compact('products', 'categories', 'category'));
    }
}
