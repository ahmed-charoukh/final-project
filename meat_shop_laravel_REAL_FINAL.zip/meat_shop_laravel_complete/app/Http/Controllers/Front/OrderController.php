<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\ShopCart;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OrderController extends Controller
{
    private function cartItems()
    {
        return ShopCart::with('product')
            ->when(auth()->check(), fn($q) => $q->where('user_id', auth()->id()))
            ->when(!auth()->check(), fn($q) => $q->where('session_id', session()->getId()))
            ->get();
    }

    public function checkout()
    {
        $categories = Category::where('status', true)->get();
        $cartItems = $this->cartItems();
        if ($cartItems->isEmpty()) {
            return redirect()->route('cart.show')->with('error', 'Cart is empty.');
        }

        $subtotal = $cartItems->sum(fn($item) => $item->product ? $item->product->price * $item->quantity : 0);
        $tax = $subtotal * 0.15;
        $shipping = 50;
        $total = $subtotal + $tax + $shipping;

        return view('front.checkout', compact('categories', 'cartItems', 'subtotal', 'tax', 'shipping', 'total'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'customer_name' => 'required|string|max:255',
            'email' => 'nullable|email|max:255',
            'phone' => 'required|string|max:50',
            'address' => 'required|string|max:255',
            'city' => 'nullable|string|max:255',
            'payment_method' => 'required|in:cash,card',
            'notes' => 'nullable|string',
        ]);

        $cartItems = $this->cartItems();
        if ($cartItems->isEmpty()) {
            return redirect()->route('cart.show')->with('error', 'Cart is empty.');
        }

        foreach ($cartItems as $item) {
            if (!$item->product || $item->product->stock < $item->quantity) {
                return redirect()->route('cart.show')->with('error', 'Some products are out of stock.');
            }
        }

        $order = DB::transaction(function () use ($validated, $cartItems) {
            $subtotal = $cartItems->sum(fn($item) => $item->product->price * $item->quantity);
            $tax = $subtotal * 0.15;
            $shipping = 50;
            $total = $subtotal + $tax + $shipping;

            $order = Order::create([
                'user_id' => auth()->id(),
                'customer_name' => $validated['customer_name'],
                'email' => $validated['email'] ?? null,
                'phone' => $validated['phone'],
                'address' => $validated['address'],
                'city' => $validated['city'] ?? null,
                'payment_method' => $validated['payment_method'],
                'subtotal' => $subtotal,
                'tax' => $tax,
                'shipping' => $shipping,
                'total' => $total,
                'notes' => $validated['notes'] ?? null,
            ]);

            foreach ($cartItems as $item) {
                OrderItem::create([
                    'order_id' => $order->id,
                    'product_id' => $item->product_id,
                    'product_name' => $item->product->title,
                    'price' => $item->product->price,
                    'quantity' => $item->quantity,
                    'total' => $item->product->price * $item->quantity,
                ]);

                Product::where('id', $item->product_id)->decrement('stock', $item->quantity);
                $item->delete();
            }

            return $order;
        });

        return redirect()->route('order.success', $order)->with('success', 'Order created successfully.');
    }

    public function success(Order $order)
    {
        $categories = Category::where('status', true)->get();
        $order->load('items');
        return view('front.order-success', compact('order', 'categories'));
    }
}
