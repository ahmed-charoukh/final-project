<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Product;
use App\Models\ShopCart;
use Illuminate\Http\Request;

class CartController extends Controller
{
    private function cartQuery()
    {
        return ShopCart::with('product')
            ->when(auth()->check(), fn($q) => $q->where('user_id', auth()->id()))
            ->when(!auth()->check(), fn($q) => $q->where('session_id', session()->getId()));
    }

    public function show()
    {
        $categories = Category::where('status', true)->get();
        $cartItems = $this->cartQuery()->get();
        $subtotal = $cartItems->sum(fn($item) => $item->product ? $item->product->price * $item->quantity : 0);
        return view('front.cart', compact('categories', 'cartItems', 'subtotal'));
    }

    public function add(Request $request, Product $product)
    {
        if (!$product->status || $product->stock <= 0) {
            return back()->with('error', 'This product is not available.');
        }

        $quantity = max(1, (int) $request->input('quantity', 1));
        $identity = auth()->check()
            ? ['user_id' => auth()->id(), 'product_id' => $product->id]
            : ['session_id' => session()->getId(), 'product_id' => $product->id];

        $item = ShopCart::firstOrNew($identity);
        $item->quantity = min(($item->exists ? $item->quantity : 0) + $quantity, $product->stock);
        $item->save();

        return redirect()->route('cart.show')->with('success', 'Product added to cart.');
    }

    public function update(Request $request, ShopCart $cart)
    {
        $this->authorizeCartItem($cart);
        $quantity = max(1, (int) $request->input('quantity', 1));
        $cart->update(['quantity' => min($quantity, $cart->product->stock)]);
        return back()->with('success', 'Cart updated.');
    }

    public function remove(ShopCart $cart)
    {
        $this->authorizeCartItem($cart);
        $cart->delete();
        return back()->with('success', 'Item removed from cart.');
    }

    private function authorizeCartItem(ShopCart $cart): void
    {
        $allowed = auth()->check()
            ? $cart->user_id === auth()->id()
            : $cart->session_id === session()->getId();

        abort_unless($allowed, 403);
    }
}
