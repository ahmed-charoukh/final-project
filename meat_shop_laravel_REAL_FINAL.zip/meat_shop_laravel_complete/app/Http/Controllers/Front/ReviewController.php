<?php
namespace App\Http\Controllers\Front;
use App\Http\Controllers\Controller;
use App\Models\Review;
use Illuminate\Http\Request;
class ReviewController extends Controller {
    public function store(Request $request) {
        $validated = $request->validate(['product_id'=>'required|exists:products,id','name'=>'required|string|max:255','rating'=>'required|integer|min:1|max:5','comment'=>'nullable|string']);
        Review::create($validated);
        return back()->with('success', 'Review added successfully.');
    }
}
