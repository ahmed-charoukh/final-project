<?php
namespace App\Http\Controllers\Front;
use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Product;
class HomeController extends Controller {
    public function index() {
        $categories = Category::where('status', true)->get();
        $featured_products = Product::with('category')->where('status', true)->latest()->limit(8)->get();
        return view('front.home', compact('categories', 'featured_products'));
    }
}
