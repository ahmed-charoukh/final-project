<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Order extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id','customer_name','email','phone','address','city','payment_method',
        'status','subtotal','tax','shipping','total','notes'
    ];

    public function items(): HasMany
    {
        return $this->hasMany(OrderItem::class);
    }
}
