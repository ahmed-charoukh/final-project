#!/usr/bin/env bash
set -e
composer install
php artisan migrate:fresh --seed
php artisan serve
