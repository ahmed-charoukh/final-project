<?php

use Illuminate\Support\Facades\Artisan;

Artisan::command('project:info', function () {
    $this->info('Meat Shop Laravel project is ready. Run php artisan migrate:fresh --seed then php artisan serve.');
})->purpose('Show project information');
