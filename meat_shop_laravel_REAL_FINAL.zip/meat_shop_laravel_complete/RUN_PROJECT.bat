@echo off
echo Installing Laravel dependencies...
composer install

echo Running migrations and seeders...
php artisan migrate:fresh --seed

echo Starting Laravel server...
php artisan serve
pause
