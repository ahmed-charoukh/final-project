Meat Shop Laravel Project - Advanced Web

Real features included:
- Front website with Blade master layout, header, menu, slider, footer, and content sections.
- Admin panel protected with real login and admin middleware.
- Admin CRUD for categories, products, and orders.
- Real product image upload using Laravel Storage public disk.
- Real database shopping cart using shop_carts table, not localStorage.
- Checkout saves orders and order_items in the database and decreases product stock.
- Contact form saves messages in messages table.
- Models, migrations, fillable properties, and relationships are included.

How to run:
1. composer install
2. cp .env.example .env
3. php artisan key:generate
4. php artisan storage:link
5. php artisan migrate:fresh --seed
6. php artisan serve

Open:
http://127.0.0.1:8000
http://127.0.0.1:8000/admin

Admin login:
Email: admin@meatshop.test
Password: 12345678

Notes:
- The /admin panel is accessible only after login by a user whose role is admin.
- Normal registered users get role customer and cannot open the admin panel.
